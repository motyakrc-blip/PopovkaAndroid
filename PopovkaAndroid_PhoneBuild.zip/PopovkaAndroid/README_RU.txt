Поповка Online — Android проект для сборки APK.
Откройте папку PopovkaAndroid в Android Studio (Open), дождитесь Gradle Sync.
Build -> Build APK(s). APK будет в app/build/outputs/apk/debug/app-debug.apk.
Игра размещена в app/src/main/assets/game.html, Firebase конфигурация подключена.
Для онлайн-функций проверьте Firebase Console: Anonymous Auth включён и Realtime Database Rules настроены.
